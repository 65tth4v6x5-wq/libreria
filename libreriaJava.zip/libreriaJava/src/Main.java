
public class Main {

  static public void main(String[] args) {

    System.out.println("APSD Libraries 2025!");

    // Aggiungere test personali!

  }

}
