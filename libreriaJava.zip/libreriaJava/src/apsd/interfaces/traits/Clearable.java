package apsd.interfaces.traits;

/** Trait: L’oggetto può essere svuotato. */
public interface Clearable {

  void Clear();

}
