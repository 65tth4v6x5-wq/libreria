package apsd.interfaces.containers.collections;

import apsd.interfaces.containers.base.IterableContainer;

public interface Set<Data> extends Collection<Data> { // Must extend Collection

  default void Union(Set<Data> set){
    set.TraverseForward(dat->{Insert(dat);return false;});
  }

   default void Difference(Set<Data> set){
    set.TraverseForward(dat->{Remove(dat);return false;});
  }


  default void Intersection(Set<Data> set){
    Filter(dat->set.Exists(dat));
  }


}
